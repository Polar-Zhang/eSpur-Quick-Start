import os

from utils import get_eSpur_deployment_abs_path, get_pdu_ip_ports_pid_json

pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
eSpur_dirs = pdu_ip_ports_pid_json.keys()
for eSpur_dir in eSpur_dirs:
    update_dir = "./" + eSpur_dir + "/eSpur/Management_node"
    print("更新"+update_dir)
    cmd1 = "cd " + update_dir
    cmd2 = "git pull"
    cmd = cmd1 + " && " + cmd2
    result = os.system(cmd)
    if result == 0:
        print("更新成功")
    else:
        print("更新不成功")
