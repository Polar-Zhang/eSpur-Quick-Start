import time
from colorama import Fore

from utils import get_pdu_ip_ports_pid_json, update_pid_is_zero_in_json
from utils import get_latest_file, get_worst_power_from_matrix_offline, get_eSpur_config, get_server_power, \
    get_data_directory, powers_to_psu_state


def stat(pdu_ip, pdu_ports_used_list, server_power_info):
    eSpur_config = get_eSpur_config()
    PSU_NUM = int(eSpur_config['psu_num'])
    # filename = "./data/" + get_latest_file("./data", "energy.txt")
    directory = get_data_directory(pdu_ip, pdu_ports_used_list)
    filename = directory + "/" + get_latest_file(directory, "energy.txt")

    with open(filename) as file_object:
        # 将文件的各行存储在一个列表中
        lines = file_object.readlines()
    file_object.close()

    for line in lines:
        line = line.rstrip()

    energy_optimal = float(lines[0])
    energy_worst = float(lines[1])
    if len(lines) == 3:
        cur_save_ratio = float(lines[2])
    else:
        cur_save_ratio = 0.0
    energy_saved = energy_worst - energy_optimal
    if energy_worst != 0:
        save_ratio = energy_saved / energy_worst
    else:
        save_ratio = 0.0
    # server_power_info = get_server_power(pdu_ip, pdu_ports_used_list)
    server_power = server_power_info[0]
    psu_state = powers_to_psu_state(server_power_info[1])
    psu_num = sum(psu_state)
    if server_power != 0:
        if psu_num == PSU_NUM:
            cur_save_ratio = 0
        server_power_without_espur = round(server_power * (1 + cur_save_ratio),1)
    else:
        server_power_without_espur = 0.0
    print("Power w/ eSpur: {} W".format(server_power))
    print("Power w/o eSpur: {} W".format(server_power_without_espur))
    # print("实时节约电量比例：{:.2%}".format((server_power_without_espur - server_power) / server_power_without_espur))
    print("Energy Consumption: {} kW·h".format(round(energy_optimal, 2)))
    print("Energy Saving: {} kW·h".format(round(energy_saved, 2)))
    print("Energy Saving Ratio: {:.2%}".format(save_ratio))


update_pid_is_zero_in_json()
pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
eSpur_dirs = pdu_ip_ports_pid_json.keys()
localtime = time.asctime(time.localtime(time.time()))
print(Fore.GREEN + localtime)
# print("--------------------------------")
for eSpur_dir in eSpur_dirs:
    print("----------------------------------------")
    parts = eSpur_dir.split("_")
    ip = parts[0]
    ports_list = parts[1].split("-")
    pid = pdu_ip_ports_pid_json[eSpur_dir]
    server_power_info = get_server_power(ip, ports_list)
    server_power = server_power_info[0]
    psu_state = powers_to_psu_state(server_power_info[1])
    state_str = ""
    for s in psu_state:
        state_str += str(s)
    print("Node_id: {}:{}:{}".format(eSpur_dir, pid, state_str))
    stat(ip, ports_list, server_power_info)
