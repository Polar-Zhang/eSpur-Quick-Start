import json, os, time, math
import numpy as np
from configparser import ConfigParser


def get_latest_file(folder_path, file_name):
    filelists = os.listdir(folder_path)

    file_to_be = []
    max_time = 0
    for file in filelists:
        if file != "test":
            file_list = file.split("_")
            if file.endswith(file_name):
                file_to_be.append(file)
                time_str = file[0:19]
                struct_time = time.strptime(time_str, "%Y-%m-%d_%H_%M_%S")
                time_stamp = time.mktime(struct_time)
                if time_stamp > max_time:
                    max_time = time_stamp
                    max_struct_time = struct_time
    for file in file_to_be:
        if file.__contains__(time.strftime("%Y-%m-%d_%H_%M_%S", max_struct_time)):
            return file


def get_eSpur_config():
    ini_file = "./config.ini"
    name = "eSpur"

    cfg = ConfigParser()
    # 读取文件内容
    cfg.read(ini_file)

    # cfg.items()返回list，元素为tuple
    eSpur_cfg = dict(cfg.items(name))
    return eSpur_cfg


def get_eSpur_deployment_abs_path():
    eSpur_config = get_eSpur_config()
    eSpur_deployment_abs_path = eSpur_config['espur_deployment_abs_path']
    return eSpur_deployment_abs_path


def get_pdu_ip_ports_pid_json():
    file_name = "pdu_ip_ports-pid.json"
    with open(file_name) as f:
        setting_pid = json.load(f)
    return setting_pid


def set_psu_command(pdu_ip, psu_no, state_str):
    """ snmpset -v1 -c private 192.168.67.122 .1.3.6.1.4.1.23273.2.4.1.0 s ON
        snmpset -v1 -c private 192.168.67.122 .1.3.6.1.4.1.23273.2.4.2.0 s ON

    :param pdu_ip:
    :type pdu_ip:
    :param psu_no:
    :type psu_no:
    :param state_str:"ON" or "OFF"
    :type state_str:
    :return:
    :rtype:
    """
    psu_command = 'snmpset -v1 -c private ' + pdu_ip + ' .1.3.6.1.4.1.23273.2.4.' + psu_no + '.0 s ' + state_str
    return psu_command


def update_pid_is_zero_in_json():
    '''只判断并更新pdu_ip_ports_pid_json.json文件中的进程是否在运行
    步骤：使用'ps -ef | grep  main'命令在获取所有的pid，判断json文件的pid是否在这查询的pid集合中，不在的话则置为0
    :return:
    :rtype:
    '''
    pids = []
    cmd = 'ps -ef | grep  main'
    infos = os.popen(cmd).readlines()
    for info in infos:
        if info.__contains__("main.py"):
            pids.append(info.split()[1])
    pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
    for key, pid in pdu_ip_ports_pid_json.items():
        if pid not in pids:
            if int(pid) != 0:
                pdu_ip_ports_pid_json[key] = 0
                print("注意！{}实例对应的pid:{}没有在后台运行，更新其json文件中pid为0".format(key, pid))
    file_path = "pdu_ip_ports-pid.json"
    with open(file_path, "w") as f:
        json.dump(pdu_ip_ports_pid_json, f)
    f.close()


def get_server_power(pdu_ip, pdu_ports_used_str):
    """
    snmpwalk -v1 -c public  192.168.67.122 .1.3.6.1.4.1.23273
    :return:
    :rtype:
    """
    pdu_ports_used_int_list = list(map(int, pdu_ports_used_str))
    get_psu_power_command = 'snmpwalk -v1 -c public  ' + pdu_ip + ' .1.3.6.1.4.1.23273'
    result = os.popen(get_psu_power_command).read().split('\n')[:-1]
    voltage_total = int(result[1].split(':')[1])

    powers = [0] * len(pdu_ports_used_str)
    for i in range(0, len(powers)):
        port_id = pdu_ports_used_int_list[i]
        port_id_encode = 10 + port_id
        powers[i] = round(int(result[port_id_encode].split(':')[1]) / 100 * voltage_total, 1)
    return round(sum(powers), 1), powers


def get_worst_power_from_matrix_offline(cur_power, cur_psu_num, threshold, pdu_ip, pdu_ports_used):
    eSpur_config = get_eSpur_config()
    PSU_NUM = int(eSpur_config['psu_num'])  # 系统配置的PSU数量
    eSpur_deployment_abs_path = get_eSpur_deployment_abs_path()
    matrix_dir = eSpur_deployment_abs_path + "/matrix"
    matrix_path = matrix_dir + "/" + get_pdu_ip_ports_str(pdu_ip, pdu_ports_used) + "_psu_config_matrix.npy"
    if not os.path.exists(matrix_path):
        return cur_power
    psu_config_matrix = np.load(matrix_path, allow_pickle=True).tolist()
    # cur_psu_num = sum(get_psu()[0])
    worst_psu_config_power_1 = 0

    for i_1 in range(PSU_NUM):
        optional_powers = psu_config_matrix[cur_psu_num - 1][i_1]
        # print("psu_num:{}, optionalPowers:{}".format(i_1 + 1, optional_powers))
        # for optional_power in optional_powers:
        for optional_power_index in range(len(optional_powers)):
            optional_power = optional_powers[optional_power_index]

            if is_power_related(optional_power[0], cur_power, threshold):
                # print("find related power:{} in optional powers:{}".format(optional_power, optional_powers))
                # to get the worst psu config through psu_config_matrix
                # 注意：这个方法可用的前提是，在构建psu_config_matrix时，按照顺序填充作为矩阵元素的list
                list_optional_power = []
                for x in range(PSU_NUM):
                    l = psu_config_matrix[x][i_1]
                    list_optional_power.append(l[optional_power_index])
                worst_psu_config_power_1 = list_optional_power[PSU_NUM - 1][0]
                # 因为阈值，mean_power 和optional_power有一定的距离，但是每次得到的worst_power却是一样的，所有对worst_power乘以一个系数
                worst_psu_config_power_1 = worst_psu_config_power_1 * (cur_power / optional_power[0])
                return round(worst_psu_config_power_1, 1)
    if worst_psu_config_power_1 == 0:
        worst_psu_config_power_1 = cur_power
    return round(worst_psu_config_power_1, 1)


def get_pdu_ip_ports_str(ip, ports_used_list):
    str1 = ip + "_"
    for port in ports_used_list:
        str1 += (str(port) + "-")
    str1 = str1[:-1]
    return str1


def is_power_related(power1, power2, threshold):
    # threshold = 0
    if threshold < 0:
        threshold = power2 / 20

    if math.fabs(power1 - power2) < threshold:
        return True
    else:
        return False


def get_data_directory(pdu_ip, pdu_ports_used):
    eSpur_deployment_abs_path = get_eSpur_deployment_abs_path()
    directory = eSpur_deployment_abs_path + "/data/" + get_pdu_ip_ports_str(pdu_ip, pdu_ports_used)
    return directory


def powers_to_psu_state(powers):
    eSpur_config = get_eSpur_config()
    PSU_NUM = int(eSpur_config['psu_num'])  # 系统配置的PSU数量
    state = [0] * PSU_NUM
    for i in range(len(powers)):
        if powers[i] > 0:
            state[i] = 1
        else:
            state[i] = 0
    return state


def get_psu_old(pdu_ip, ports_list_int):
    """snmpwalk -v1 -c public 192.168.0.11 .1.3.6.1.4.1.23273

    :return:
    :rtype:
    """
    # get psu's power operation start time
    start_time = time.time()
    get_psu_power_command = 'snmpwalk -v1 -c public  ' + pdu_ip + ' .1.3.6.1.4.1.23273'
    result = os.popen(get_psu_power_command).read().split('\n')[:-1]
    # state_2_1 = result[19].split(':')[1].strip()
    # state_2_2 = result[20].split(':')[1].strip()
    states = []
    for i in ports_list_int:
        state_str = result[19 + i].split(':')[1].strip()
        states.append(state_str)
    # print(states)
    state = [0] * len(ports_list_int)
    for i in range(len(states)):
        if states[i] == '"ON "':
            state[i] = 1
        elif states[i] == '"OFF"':
            state[i] = 0
    # get psu's power operation end time
    end_time = time.time()
    get_operation_time = end_time - start_time
    # print('get operation time is {}'.format(get_operation_time))
    return state, get_operation_time
