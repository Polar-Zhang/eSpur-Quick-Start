import os
import signal
import sys

from utils import get_pdu_ip_ports_pid_json

args = sys.argv
if len(args) != 2:
    print("正确使用方法：python shutdown_eSpur.py [pid](0代表关闭json中的全部)")
else:
    pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
    pid = int(args[1])
    if pid == 0:
        for key, value in pdu_ip_ports_pid_json.items():
            if int(value) != 0:
                print("关闭" + key)
                os.kill(int(value), signal.SIGINT)
    else:
        is_exists = False
        for key, value in pdu_ip_ports_pid_json.items():
            if int(value) == pid:
                print("关闭" + key)
                is_exists = True
                os.kill(pid, signal.SIGINT)
        if not is_exists:
            print("pid={}不存在对应的eSpur实例".format(pid))
