import configparser
import json

file_name = "pdu_ip_ports-pid.json"
with open(file_name) as f:
    setting_pid = json.load(f)
eSpur_dirs = list(setting_pid.keys())

config_file_path_origin = "./config.ini"
config = configparser.ConfigParser()
config.read(config_file_path_origin)
section = "eSpur"
# eSpur_cfg = dict(config.items(section))
# print(eSpur_cfg)
single_psu_max_power = config.get(section, "single_psu_max_power")
single_psu_max_powers = single_psu_max_power.split("-")
instance_id = config.get(section, "instance_id")
instance_ids = config.get(section, "instance_id").split("-")

for i in range(len(eSpur_dirs)):
    eSpur_dir = eSpur_dirs[i]
    parts = eSpur_dir.split("_")
    ip = parts[0]
    pdu_ports_used = parts[1]
    ports_list = pdu_ports_used.split("-")
    print(ip, ports_list)

    # config.add_section(section)
    config.set(section, "pdu_ip", ip)
    config.set(section, "pdu_ports_used", pdu_ports_used)
    config.set(section, "psu_num", str(len(ports_list)))
    if len(instance_ids) == 1:
        config.set(section, "instance_id", instance_id)
    else:
        config.set(section, "instance_id", instance_ids[i])
        print("instance_id:{}".format(instance_ids[i]))

    if len(single_psu_max_powers) == 1:
        config.set(section, "single_psu_max_power", single_psu_max_power)
    else:
        config.set(section, "single_psu_max_power", single_psu_max_powers[i])
        print("single_psu_max_power:{}".format(single_psu_max_powers[i]))

    # "/home/pi/eSpur-deployment/192.168.0.12_1-2-3-4/eSpur/Management_node/config/config.ini"
    config_file_path = "./" + eSpur_dir + "/eSpur/Management_node/config/config.ini"
    with open(config_file_path, "w") as f:
        config.write(f)
    f.close()
    print(eSpur_dir + "的配置更新完成！")
