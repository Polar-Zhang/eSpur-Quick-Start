import numpy as np
import os

from utils import get_pdu_ip_ports_pid_json

pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
eSpur_dirs = pdu_ip_ports_pid_json.keys()
print("-----------------------------")
for eSpur_dir in eSpur_dirs:
    print(eSpur_dir + ":")
    matrix_path = "./matrix/" + eSpur_dir + "_psu_config_matrix.npy"
    if os.path.exists(matrix_path):
        psu_config_matrix = np.load(matrix_path, allow_pickle=True).tolist()
        print(psu_config_matrix)
    else:
        print("{} doesn't exist.".format(matrix_path))
    print("-----------------------------")
