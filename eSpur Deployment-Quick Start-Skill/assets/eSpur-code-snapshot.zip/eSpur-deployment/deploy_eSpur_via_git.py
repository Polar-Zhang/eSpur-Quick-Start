import os

from utils import get_pdu_ip_ports_pid_json

pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
eSpur_dirs = pdu_ip_ports_pid_json.keys()
for eSpur_dir in eSpur_dirs:
    os.makedirs(eSpur_dir, exist_ok=True)
    os.system("chmod 777 " + eSpur_dir)
    print("创建文件夹/" + eSpur_dir + "成功")
    cmd1 = "cd ./" + eSpur_dir
    cmd2 = "git clone git@github.com:guomingtang/eSpur.git"
    cmd = cmd1 + " && " + cmd2
    result = os.system(cmd)
    if result == 0:
        print("下载eSpur成功")
    else:
        print("下载eSpur不成功")

"""
接下来从github上 git clone git@github.com:guomingtang/eSpur.git，或者从其他位置复制到相应的文件夹
"""
