import os
import sys

from utils import get_pdu_ip_ports_pid_json, get_latest_file

args = sys.argv
if len(args) != 2:
    print("正确使用方法：python print_log.py [eSpur实例路径,比如192.168.0.12_1-2-3-4]")
else:
    eSpur_dir = args[1]
    pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
    eSpur_dirs = pdu_ip_ports_pid_json.keys()
    if eSpur_dir in eSpur_dirs:
        log_dir = "./log/" + eSpur_dir
        cmd1 = "cd " + log_dir
        latest_log = get_latest_file(log_dir, "log")
        cmd2 = "tail -f " + latest_log
        cmd = cmd1 + " && " + cmd2
        os.system(cmd)
    else:
        print("{}没有在json文件中配置，请检查参数是否正确".format(eSpur_dir))
