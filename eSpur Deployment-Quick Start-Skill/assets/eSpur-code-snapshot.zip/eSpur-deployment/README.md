### eSpur的部署步骤

1. 下载eSpur-deployment或者直接粘贴复制

   ```shell
   git clone git@github.com:beerjtu/eSpur-deployment.git
   ```

2. 进入eSpur-deployment文件夹,修改**config.ini**中的参数

   ```shell
   cd eSpur-deployment
   ```
   >修改config.ini中的espur_deployment_abs_path项，此项为该项目部署的绝对路径，比如/home/pi/eSpur-deployment；以及single_psu_max_power（单个PSU最大的额定功率）；vpn_ip(espur对外的ip，一般是vpn ip) 
pdu_ports_num（pdu所有的端口数量）
   ```shell
   nano ./config.ini
   ```
   
3. 修改**pdu_ip_ports-pid.json**文件

   * 该json文件内容为：
      > {"192.168.0.12_1-2-3-4": "0", "192.168.0.12_5-6-7-8": "3571"}

      其中，其中json文件的key，比如"192.168.0.12_1-2-3-4"的组成为[pdu    ip]_[port 1]-[port 2]-...-[port n]。json文件value的初始化值配置为"0"，该value值在eSpur实例运行时代表实例运行的pid，为0时代表该实例没有运行。
      
   * 该json文件中的"192.168.0.12_1-2-3-4"将会用于更新每个eSpur实例的pdu_ip、pdu_ports_used和psu_num三个配置项（通过[update_config.py](./update_config.py)）

4. 部署pdu_ip_ports-pid.json文件中配置的eSpur实例的代码

   * [deploy_eSpur_via_git.py](./deploy_eSpur_via_git.py)：从github上下载eSpur代码，（注意，在下载之前，需要配置公钥）
      ```shell
      python deploy_eSpur_via_git.py
      ```
   * [deploy_eSpur_via_unzip.py](./deploy_eSpur_via_unzip.py)：通过解压./eSpur.zip代码来部署，注意eSpur.zip中的文件也必须是eSpur而不是eSpur-main
      ```shell
      python deploy_eSpur_via_unzip.py
      ```
   * [update_eSpur_code_via_git.py](./update_eSpur_code_via_git.py)：从github上更新eSpur实例的代码
      ```shell
      python update_eSpur_code_via_git.py
      ```

5. 更新每个eSpur实例的配置文件

   * [update_config.py](./update_config.py):更新eSpur/Management_node/config/config.ini文件

     ```shell
     python update_config.py
     ```

   * 主要更新/config/config.ini文件中的pdu_ip, ports_used，psu_num，single_psu_max_power等配置

6. 启动eSpur实例

   * [run_eSpur.py](./run_eSpur.py)
      * 可以启动json文件中配置的所有eSpur实例
         ```shell
         python run_eSpur.py 0
         ```
      * 也可以启动指定的eSpur实例（必须在json文件中配置）
         ```shell
         python run_eSpur.py 192.168.0.12_1-2-3-4
         ```

   * 在运行run_eSpur.py之前，可以使用[stat_eSpur.py](./stat_eSpur.py)或者ps命令来查看eSpur实例的运行情况
      ```shell
      # 从该命令可以到eSpur实例的pid，若为0，说明没有在运行
      python stat_eSpur.py
      # 或者
      ps -ef | grep main.py
      ```

7. 关闭eSpur实例

   * [shutdown_eSpur.py](./shutdown_eSpur.py)
      * 可以关闭json文件中配置的所有eSpur实例
         ```shell
         python shutdown_eSpur.py 0
         ```
      * 也可关闭指定的eSpur实例（必须在json文件中配置）
         ```shell
         python shutdown_eSpur.py 192.168.0.12_1-2-3-4
         ```

8. 删除eSpur实例的配置

   * [delete_eSpur.py](./delete_eSpur.py)
      * 可以删除json文件中配置的所有eSpur实例的文件夹
         ```shell
         python shutdown_eSpur.py 0
         ```
      * 也可以启动指定的eSpur实例的文件夹（必须在json文件中配置）
         ```shell
         python shutdown_eSpur.py 192.168.0.12_1-2-3-4
         ```
   * 或者直接使用rm命令
     ```shell
     rm -rf 192.168.0.12_1-2-3-4
     ```

* 需要**注意**json文件的配置以及config.ini配置文件

### 辅助功能

1. 查看统计信息

   ```sh
   python stat_eSpur.py 
   ```

2. 实时打印日志

   ```sh
   python print_log.py [eSpur实例路径,比如192.168.0.12_1-2-3-4]
   ```

3. 打印psu_config_matrix

   ```sh
   python print_matrix.py
   ```

   
