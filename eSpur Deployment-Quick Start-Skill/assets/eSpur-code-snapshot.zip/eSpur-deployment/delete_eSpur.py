import os
import sys

from utils import get_pdu_ip_ports_pid_json

args = sys.argv


def delete_single_eSpur(eSpur_dir):
    if os.path.exists(eSpur_dir):
        cmd = "rm -rf ./" + eSpur_dir
        result = os.system(cmd)
        if result == 0:
            print("删除{}成功".format(eSpur_dir))
        else:
            print("删除{}失败".format(eSpur_dir))
    else:
        print(eSpur_dir+"不存在")


if len(args) != 2:
    print("正确使用方法：python delete_eSpur.py [eSpur实例路径,比如192.168.0.12_1-2-3-4](0代表json中的全部)")
else:
    pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
    eSpur_dirs = pdu_ip_ports_pid_json.keys()
    if len(args[1]) == 1:
        for eSpur_dir in eSpur_dirs:
            delete_single_eSpur(eSpur_dir)
    else:
        eSpur_dir = args[1]
        if eSpur_dir in eSpur_dirs:
            delete_single_eSpur(eSpur_dir)
        else:
            print("{}在json文件中不存在".format(eSpur_dir))
