import os
import sys
from utils import get_eSpur_config, set_psu_command

args = sys.argv
eSpur_config = get_eSpur_config()
pdu_port_num = int(eSpur_config['pdu_ports_num'])  # pdu的端口数量
pdu_ip = eSpur_config['pdu_ip']  # pdu的ip地址
if len(args) <= 1:
    print("使用方法为：python set_pdu_state 「需要设置的端口号，从1开始, 0表示开启所有端口，此时不需要下一个参数」「需要设置的状态，1代表开启，0代表关闭」")
elif len(args) == 2:
    arg1 = args[1]
    if int(arg1) == 0:
        for port in reversed(range(1, pdu_port_num + 1)):
            set_command = set_psu_command(pdu_ip, str(port), "ON")
            os.system(set_command)
else:
    port = args[1]
    state = args[2]
    if int(port) < 1 or int(port) > pdu_port_num:
        print("端口号错误！")
    else:
        if int(state) == 0:
            state_str = "OFF"
        else:
            state_str = "ON"
        set_command = set_psu_command(pdu_ip, port, state_str)
        print(set_command)
        os.system(set_command)
