import os
import sys
import time

args = sys.argv

if len(args) == 1:
    period = "2"
else:
    period = args[1]
while True:
    time.sleep(int(period))
    os.system("python stat_eSpur.py")
