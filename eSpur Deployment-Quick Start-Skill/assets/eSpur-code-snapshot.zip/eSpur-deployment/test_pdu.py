import os
import sys
import time


def get_psu_old():
    """snmpwalk -v1 -c public 192.168.0.11 .1.3.6.1.4.1.23273

    :return:
    :rtype:
    """
    # get psu's power operation start time
    start_time = time.time()
    get_psu_power_command = 'snmpwalk -v1 -c public  ' + pdu_ip + ' .1.3.6.1.4.1.23273'
    result = os.popen(get_psu_power_command).read().split('\n')[:-1]
    # state_2_1 = result[19].split(':')[1].strip()
    # state_2_2 = result[20].split(':')[1].strip()
    states = []
    for i in range(PSU_NUM):
        state_str = result[19 + i].split(':')[1].strip()
        states.append(state_str)
    # print(states)
    state = [0] * PSU_NUM
    for i in range(len(states)):
        if states[i] == '"ON "':
            state[i] = 1
        elif states[i] == '"OFF"':
            state[i] = 0
    # get psu's power operation end time
    end_time = time.time()
    get_operation_time = end_time - start_time
    # print('get operation time is {}'.format(get_operation_time))
    return state, get_operation_time


def set_psu_command(pdu_ip, psu_no, state_str):
    """ snmpset -v1 -c private 192.168.67.122 .1.3.6.1.4.1.23273.2.4.1.0 s ON
        snmpset -v1 -c private 192.168.67.122 .1.3.6.1.4.1.23273.2.4.2.0 s ON

    :param pdu_ip:
    :type pdu_ip:
    :param psu_no:
    :type psu_no:
    :param state_str:"ON" or "OFF"
    :type state_str:
    :return:
    :rtype:
    """
    psu_command = 'snmpset -v1 -c private ' + pdu_ip + ' .1.3.6.1.4.1.23273.2.4.' + psu_no + '.0 s ' + state_str
    return psu_command


def set_one_psu(pdu_ip, psu_no, state_str):
    start_time = time.time()
    psu_command = set_psu_command(pdu_ip, psu_no, state_str)
    print("set_psu_command:{}".format(psu_command))
    psu_state = os.popen(psu_command).read().split(':')[1]
    time_spent = time.time() - start_time
    # print("pdu {} psu {} set time:{}".format(pdu_ip, psu_no, time.time() - start_time))
    return time_spent


def set_psu(state):
    # set operation's start time
    start_time = time.time()
    if sum(state) < 1:
        print('can\'t turn off all the PSU!')
        return
    elif sum(state) > PSU_NUM:
        print('wrong state(>PSU_NUM):{}'.format(state))
        return
    else:
        print("set PSU input: {}".format(state))
        states_to_be_set = ["ON"] * PSU_NUM
        for i in range(len(state)):
            if state[i] == 1:
                states_to_be_set[i] = "ON"
            if state[i] == 0:
                states_to_be_set[i] = 'OFF'
    set_time = [0.0] * (PSU_NUM + 2)
    cur_psu_state, get_operation_time = get_psu_old()
    # 代表需要被设置psu
    psu_to_be_set = []
    for i in range(len(state)):
        if state[i] != cur_psu_state[i]:
            psu_to_be_set.append(i)
    print("psu index number to be set(index number starts from 0):{}".format(psu_to_be_set))

    while True:
        # set_time[0] = set_one_psu(pdu_ip, '1', states[0])
        # set_time[1] = set_one_psu(pdu_ip, '2', states[1])
        # set_time[2] = set_one_psu(pdu_ip, '3', states[2])
        # set_time[3] = set_one_psu(pdu_ip, '4', states[3])
        for i in psu_to_be_set:
            # 注意，这里使用了pdu_ports_used，是str类型
            set_time[i] = set_one_psu(pdu_ip, pdu_ports_used[i], states_to_be_set[i])

        set_time_all = time.time() - start_time
        set_time[PSU_NUM] = set_time_all

        # 这里需要一个即时判断PSU设置成功的方法
        # 按照这里的方法，设置之后来再获取PSU的状态来对比，这样实时性不足
        # 另外，还有一个问题，按照这里的设置第一个PSU将是使用频率最高的PSU，损耗最严重，是否设计一种方法，使之均衡使用

        cur_psu_state, get_operation_time = get_psu_old()
        print("current psu state:{}".format(cur_psu_state))

        # 来逐位比较，没有设置成功的再进行重新设置
        if state == cur_psu_state:
            # set operation's end time
            end_time = time.time()
            set_operation_time = end_time - start_time
            print(
                'set psu successfully!, current PSU state:{}, time spent:{}'.format(state, set_operation_time))
            set_time[PSU_NUM + 1] = get_operation_time
            return set_time
        else:
            psu_to_be_set = []
            for i in range(len(state)):
                if state[i] != cur_psu_state[i]:
                    psu_to_be_set.append(i)
            time.sleep(0.3)
            continue


def psu_num_to_psu_state(psu_num):
    """ convert the number of active psu to the state of psus. e.g. 2 active psu--->[1,1,0,0]

    :param psu_num:
    :return:
    """
    psu_state = [0] * PSU_NUM
    for i in range(0, psu_num):
        psu_state[i] = 1
    return psu_state


PSU_NUM = 8
pdu_ports_used = [str(value + 1) for value in range(PSU_NUM)]
args = sys.argv
if len(args) != 2:
    print("正确使用方法：python test_pdu.py [pdu_ip]；谨慎使用！，开关所有PDU端口可能造成服务器宕机！！")
else:
    pdu_ip = args[1]
    for i in range(PSU_NUM):
        print("----------{}------------".format(PSU_NUM - i))
        set_psu(psu_num_to_psu_state(PSU_NUM - i))
        time.sleep(0.5)

    for i in range(PSU_NUM):
        print("----------{}------------".format(i+1))
        set_psu(psu_num_to_psu_state(i + 1))
        time.sleep(0.5)



