import os
import sys

from utils import get_pdu_ip_ports_pid_json, get_eSpur_deployment_abs_path, update_pid_is_zero_in_json


def monitor_single_server(eSpur_dir):
    exec_dir = get_eSpur_deployment_abs_path() + "/" + eSpur_dir + "/eSpur/Management_node"
    print("打开" + exec_dir)
    cmd1 = "cd " + exec_dir
    cmd2 = "nohup python monitor_server_power.py >/dev/null 2>&1 &"
    cmd = cmd1 + " && " + cmd2
    result = os.system(cmd)
    if result == 0:
        print("执行nohup python monitor_server_power.py >/dev/null 2>&1 &成功")
    else:
        print("执行不成功")


args = sys.argv
# update_pid_is_zero_in_json()
if len(args) != 2:
    print("正确使用方法：python monitor_server_power.py [eSpur实例路径,比如192.168.0.12_1-2-3-4](0代表开启全部)")
else:
    pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
    eSpur_dirs = pdu_ip_ports_pid_json.keys()
    if len(args[1]) == 1:
        for eSpur_dir in eSpur_dirs:
            monitor_single_server(eSpur_dir)
    else:
        eSpur_dir = args[1]
        if eSpur_dir in eSpur_dirs:
            monitor_single_server(eSpur_dir)
        else:
            print("{}在json文件中不存在".format(eSpur_dir))
