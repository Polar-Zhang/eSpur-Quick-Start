import os
import sys

args = sys.argv

if len(args) == 1:
    period = "2"
else:
    period = args[1]
os.system("watch --color -n " + period + " -t python stat_eSpur.py")
