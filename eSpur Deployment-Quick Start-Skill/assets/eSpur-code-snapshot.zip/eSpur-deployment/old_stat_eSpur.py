import os

from utils import get_pdu_ip_ports_pid_json, update_pid_is_zero_in_json

update_pid_is_zero_in_json()
pdu_ip_ports_pid_json = get_pdu_ip_ports_pid_json()
eSpur_dirs = pdu_ip_ports_pid_json.keys()
print("--------------------------------")
for eSpur_dir in eSpur_dirs:
    parts = eSpur_dir.split("_")
    ip = parts[0]
    pdu_ports_used = parts[1]
    ports_list = pdu_ports_used.split("-")
    pid = pdu_ip_ports_pid_json[eSpur_dir]
    print("{}, pid:{}".format(eSpur_dir, pid))
    cmd1 = "cd ./" + eSpur_dir + "/eSpur/Management_node"
    cmd2 = "python stat.py"
    cmd = cmd1 + " && " + cmd2
    os.system(cmd)
    print("--------------------------------")
