from utils import get_psu_old, get_eSpur_config, get_server_power

eSpur_config = get_eSpur_config()
pdu_port_num = int(eSpur_config['pdu_ports_num'])  # pdu的端口数量
pdu_ip = eSpur_config['pdu_ip']  # pdu的ip地址
pdu_state = get_psu_old(pdu_ip, list(range(pdu_port_num)))
print("ip:{}, ports_num:{}".format(pdu_ip, pdu_port_num))

ports_str = [str(i) for i in range(1, pdu_port_num + 1)]
pdu_power = get_server_power(pdu_ip, ports_str)
print("NO.|state|power")
for i in range(pdu_port_num):
    print(" {} |  {}  |{}".format(i+1, pdu_state[0][i], pdu_power[1][i]))