from flask import Flask, session, g
import config
from exts import db, mail
from flask_migrate import Migrate
# from models import EmailCaptchaModel 放到user.py中，为了迁移能检测到

# 将其写到__init__.py中
# from blurprints.qa import bp as qa_bp
# from blurprints.user import bp as user_bp
from blurprints import qa_bp, user_bp, stat_bp, manage_bp, index_bp
from models import UserModel

app = Flask(__name__)
app.config.from_object(config)
db.init_app(app)
mail.init_app(app)

# flask db init
# flask db migrate 生成迁移脚本,需要导入model文件
# flask db upgrade 隐射到数据中
migrate = Migrate(app, db)

app.register_blueprint(qa_bp)
app.register_blueprint(user_bp)
app.register_blueprint(stat_bp)
app.register_blueprint(manage_bp)
app.register_blueprint(index_bp)


@app.before_request
def before_request():
    user_id = session.get("user_id")
    # print("before_request", user_id)
    if user_id:
        try:
            user = UserModel.query.get(user_id)
            # # 给g绑定一个叫做user的变量，他的值是user这个变量
            # setattr(g, "user", user)
            g.user = user
            # print("g.user.username", g.user.username)
        except:
            g.user = None


# 上下文处理器
# 求情-->before_request->视图函数-->视图函数中返回模板-->context_processor
@app.context_processor
def context_processor():
    if hasattr(g, "user"):
        return {"user": g.user}
    else:
        return {}


if __name__ == '__main__':
    app.run()
