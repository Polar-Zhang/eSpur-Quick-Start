from flask import Blueprint, render_template

bp = Blueprint("index", __name__, url_prefix="/index")


@bp.route("/about_us")
def about_us():
    return render_template("about_us.html")

@bp.route("/espur")
def espur():
    return render_template("espur.html")
