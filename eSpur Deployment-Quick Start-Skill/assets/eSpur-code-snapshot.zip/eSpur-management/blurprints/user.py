import random
import string
from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, jsonify, session, flash
from flask_mail import Message
from werkzeug.security import generate_password_hash, check_password_hash

from exts import mail, db
from models import EmailCaptchaModel, UserModel
from .forms import RegisterForm, LoginForm

bp = Blueprint("user", __name__, url_prefix="/user")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    else:
        form = LoginForm(request.form)
        if form.validate():
            email = form.email.data
            password = form.password.data
            user = UserModel.query.filter_by(email=email).first()
            if user and check_password_hash(user.password, password):
                # 将user.id放入到session中
                session["user_id"] = user.id
                return redirect("/")
            else:
                flash("邮箱和密码不匹配")
                return redirect(url_for("user.login"))
        else:
            flash("邮箱或密码格式错误")
            return redirect(url_for("user.login"))


@bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("user.login"))


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    else:
        form = RegisterForm(request.form)
        if form.validate():
            # 邮箱的重复验证也在froms.py中
            email = form.email.data
            # 验证码验证在forms.py中
            username = form.username.data
            # print(username)
            password = form.password.data
            # md5
            hash_password = generate_password_hash(password)
            # role_id=2表示默认的注册的用户为普通用户
            user = UserModel(email=email, username=username, password=hash_password, role_id=2)
            db.session.add(user)
            db.session.commit()
            return redirect(url_for("user.login"))
        else:
            return redirect(url_for("user.register"))


@bp.route("/captcha", methods=["POST"])
def get_captcha():
    # http://127.0.0.1:5000/user/captcha?email=beerjtu@163.com
    # email = request.args.get("email")
    # 注意这里是form
    email = request.form.get("email")
    print("email", email)
    letters = string.ascii_letters + string.digits
    captcha = "".join(random.sample(letters, 4))
    if mail:
        message = Message(subject="eSpur用户注册",
                          recipients=[email],
                          body=f"【eSpur】您的注册验证码为:{captcha}")
        mail.send(message)
        # 先要查询邮箱是否已被发送验证码
        captcha_model = EmailCaptchaModel.query.filter_by(email=email).first()
        if captcha_model:
            # 如果已被发送，则更新验证码及其时间
            captcha_model.captcha = captcha
            captcha_model.create_time = datetime.now()
            db.session.commit()
        else:
            # 否则插入新数据
            captcha_model = EmailCaptchaModel(email=email, captcha=captcha)
            db.session.add(captcha_model)
            db.session.commit()
        # code:200
        return jsonify({"code": 200})
    else:
        # code:400客户端错误
        print("邮箱为空")
        return jsonify({"code": 400, "message": "邮箱为空"})
