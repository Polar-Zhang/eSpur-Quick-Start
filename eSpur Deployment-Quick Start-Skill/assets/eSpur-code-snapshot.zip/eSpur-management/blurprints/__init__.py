from .qa import bp as qa_bp
from .user import bp as user_bp
from .stat import bp as stat_bp
from .manage import bp as manage_bp
from .index import bp as index_bp
