from flask import Blueprint, render_template
from decroators import login_required

bp = Blueprint("manage", __name__, url_prefix="/manage")


@bp.route("/")
@login_required
def index():
    return render_template("manage.html")
