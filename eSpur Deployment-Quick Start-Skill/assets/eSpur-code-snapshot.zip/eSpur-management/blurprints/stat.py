import time
from datetime import datetime, timedelta

from flask import Blueprint, render_template, request, jsonify, g

from decroators import login_required
from exts import db
from models import eSpurInstanceModel, eSpurInstanceStatModel, eSpurInstancePowerTimeModel, \
    eSpurInstanceRealtimePowerTimeModel, UserInstanceModel

bp = Blueprint("stat", __name__, url_prefix="/stat")


@bp.route("/")
@login_required
def index():
    role_id = g.user.role_id
    # 1代表管理员
    if role_id == 1:
        page = request.args.get('page', 1, type=int)
        pagination = eSpurInstanceModel.query.paginate(page, per_page=6, error_out=False)
        espur_instances = pagination.items
    else:
        user_instances = UserInstanceModel.query.filter_by(user_id=g.user.id).all()
        instance_ids = []
        for user_instance in user_instances:
            instance_ids.append(user_instance.instance_id)
        page = request.args.get('page', 1, type=int)
        pagination = eSpurInstanceModel.query.filter(eSpurInstanceModel.id.in_(instance_ids)).paginate(page, per_page=6,
                                                                                                       error_out=False)
        espur_instances = pagination.items

    return render_template("stat.html", espur_instances=espur_instances, pagination=pagination)


@bp.route(("/stat"), methods=["POST"])
def stat():
    instance_id = request.form.get("instance_id")
    # print(instance_id)
    stats = eSpurInstanceStatModel.query.filter_by(instance_id=instance_id).all()
    # print(stats)
    optimal_energy = 0
    worst_energy = 0
    save_ratio = 0
    for stat in stats:
        optimal_energy += stat.optimal_energy
        worst_energy += stat.worst_energy
    energy_saved = worst_energy - optimal_energy
    if worst_energy != 0:
        save_ratio = int(round(energy_saved / worst_energy, 4) * 10000)
    #  注意这里传回去的都是整数，在js中处理一下，都除以100
    return jsonify({"code": 200, "save_ratio": save_ratio, "energy_consumed": optimal_energy,
                    "energy_saved": energy_saved})


@bp.route(("/realtime_power"), methods=["POST"])
def realtime_power():
    instance_id = request.form.get("instance_id")
    # print(instance_id)
    x_label = list()
    y_data = list()
    y_data1 = list()
    instance_stat = eSpurInstanceStatModel.query.filter_by(instance_id=instance_id).order_by(
        db.text("-espur_start_time")).first()

    cur_save_ratio = 0
    cur_psu_state = '10101'
    time_now = datetime.now()
    if instance_stat:
        # power_times = eSpurInstancePowerTimeModel.query.filter_by(instance_id=instance_id).order_by(
        #     db.text("-timestamp")).limit(100).all()
        power_times = eSpurInstanceRealtimePowerTimeModel.query.filter(
            eSpurInstanceRealtimePowerTimeModel.instance_id == instance_id,
            eSpurInstanceRealtimePowerTimeModel.timestamp >= time_now - timedelta(
                minutes=10)).order_by(
            db.text("-timestamp")).all()
        if power_times:
            cur_save_ratio = power_times[0].cur_save_ratio
            cur_psu_state = power_times[0].cur_psu_state
            for power_time in power_times:
                x_label.insert(0, power_time.timestamp.strftime("%H:%M:%S"))
                y_data.insert(0, power_time.power / 100)
            # y_data1.insert(0, power_time.power * (1 + ratio) / 10000)

    return jsonify({"code": 200, "xLabel": x_label, "yData": y_data, "yData1": y_data1, "ratio": cur_save_ratio,
                    "state": cur_psu_state})


# 详细数据页面
@bp.route("/detail")
def stat_detail():
    instance_id = request.args.get('id')
    instance = eSpurInstanceModel.query.filter_by(id=instance_id).first()
    return render_template("detail.html", instance=instance)


@bp.route("/detail/graph", methods=['POST'])
def detail_graph():
    instance_id = request.form.get("instance_id")
    start_time = convert_time_format(request.form.get("start_time"))
    end_time = convert_time_format(request.form.get("end_time"))

    instance_stat = eSpurInstanceStatModel.query.filter_by(instance_id=instance_id).order_by(
        db.text("-espur_start_time")).first()

    NOW = datetime.now()

    x_label = list()
    state_date = list()
    y_data = list()
    y_data1 = list()
    cur_save_ratio = 0
    cur_psu_state = '10101'

    if instance_stat:
        power_times = eSpurInstancePowerTimeModel.query.filter(eSpurInstancePowerTimeModel.instance_id == instance_id,
                                                               eSpurInstancePowerTimeModel.timestamp >= start_time,
                                                               eSpurInstancePowerTimeModel.timestamp <= end_time).order_by(
            db.text("-timestamp")).all()
        cur_save_ratio = power_times[0].cur_save_ratio
        cur_psu_state = power_times[0].cur_psu_state
        for power_time in power_times:
            x_label.insert(0, power_time.timestamp.strftime("%d-%H:%M:%S"))
            state_date.insert(0, state_str_to_num(power_time.cur_psu_state))
            y_data.insert(0, round(power_time.power / 100, 2))
            # y_data1.insert(0, round((power_time.power / 100) * (power_time.cur_save_ratio / 100000), 2))

    return jsonify({"code": 200, "xLabel": x_label,
                    "stateData": state_date,
                    "yData": y_data,
                    "yData1": y_data1,
                    "ratio": cur_save_ratio,
                    "state": cur_psu_state})


def state_str_to_num(state_str):
    res = 0
    state_list = list(state_str)
    for state in state_list:
        res += int(state)
    return res


def convert_time_format(t):
    # 2022-05-23T02:55
    # 2022-05-23 14:52:31.683926
    time_stamp = time.strptime(t, '%Y-%m-%dT%H:%M')
    format_time = time.strftime("%Y-%m-%d %H:%M:%S", time_stamp)
    return format_time
