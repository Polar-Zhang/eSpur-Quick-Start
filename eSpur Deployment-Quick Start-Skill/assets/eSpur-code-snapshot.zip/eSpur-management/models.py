from datetime import datetime

from sqlalchemy.dialects.mysql import DATETIME

from exts import db


# 历史数据
class eSpurInstancePowerTimeModel(db.Model):
    __tablename__ = "espur_instance_power_time"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    power = db.Column(db.Integer)
    timestamp = db.Column(DATETIME(fsp=6))
    cur_save_ratio = db.Column(db.Integer)
    cur_psu_state = db.Column(db.String(15))
    # instance_id = db.Column(db.Integer, db.ForeignKey("espur_instance.id"))
    instance_id = db.Column(db.Integer)

    # instance = db.relationship("eSpurInstanceModel", backref="powers")


# 实时数据
class eSpurInstanceRealtimePowerTimeModel(db.Model):
    __tablename__ = "espur_instance_real_time_power_time"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    power = db.Column(db.Integer)
    timestamp = db.Column(DATETIME(fsp=6))
    cur_save_ratio = db.Column(db.Integer)
    cur_psu_state = db.Column(db.String(15))
    # instance_id = db.Column(db.Integer, db.ForeignKey("espur_instance.id"))
    instance_id = db.Column(db.Integer)


class KnowledgeModel(db.Model):
    __tablename__ = "knowledge"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    timestamp = db.Column(DATETIME(fsp=6))
    # knowledge 的组成：[psu_num, [m, pacing, cv, median, max, min]]
    psu_state = db.Column(db.String(15))
    mean_power = db.Column(db.Integer)
    pacing = db.Column(db.Integer)
    cv = db.Column(db.Integer)
    median = db.Column(db.Integer)
    max = db.Column(db.Integer)
    min = db.Column(db.Integer)

    instance_id = db.Column(db.Integer)


class eSpurInstanceModel(db.Model):
    __tablename__ = "espur_instance"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    pdu_ports = db.Column(db.String(20), nullable=False)
    equipment_id = db.Column(db.Integer, db.ForeignKey("espur_equipment.id"))

    equipment = db.relationship("eSpurEquipmentModel", backref="instances")


# 存放由eSpur实例存储的统计信息
class eSpurInstanceStatModel(db.Model):
    __tablename__ = "espur_instance_stat"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    optimal_energy = db.Column(db.Integer)
    worst_energy = db.Column(db.Integer)
    # cur_save_ratio = db.Column(db.Integer)
    espur_start_time = db.Column(db.DateTime)

    instance_id = db.Column(db.Integer, db.ForeignKey("espur_instance.id"))

    instance = db.relationship("eSpurInstanceModel", backref="stats")


class eSpurEquipmentModel(db.Model):
    __tablename__ = "espur_equipment"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    version = db.Column(db.String(20), nullable=False)
    location = db.Column(db.String(200))
    external_ip = db.Column(db.String(15))
    pdu_ip = db.Column(db.String(15))
    deployment_date = db.Column(db.Date)
    notes = db.Column(db.String(200))


class EmailCaptchaModel(db.Model):
    __tablename__ = "email_captcha"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(100), nullable=False, unique=True)
    captcha = db.Column(db.String(20), nullable=False)
    # 注意这里now不加括号
    create_time = db.Column(db.DateTime, default=datetime.now)


class UserModel(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(200), nullable=False, unique=True)
    email = db.Column(db.String(100), nullable=False, unique=True)
    password = db.Column(db.String(200), nullable=False)
    join_time = db.Column(db.DateTime, default=datetime.now)
    role_id = db.Column(db.Integer, nullable=False)


class RoleModel(db.Model):
    __tablename__ = "role"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(200), nullable=False, unique=True)


class UserInstanceModel(db.Model):
    __tablename__ = "user_instance"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, nullable=False)
    instance_id = db.Column(db.Integer, nullable=False)


class QuestionModel(db.Model):
    __tablename__ = "question"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    create_time = db.Column(db.DateTime, default=datetime.now)
    author_id = db.Column(db.Integer, db.ForeignKey("user.id"))

    author = db.relationship("UserModel", backref="questions")


class AnswerModel(db.Model):
    __tablename__ = "answer"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    content = db.Column(db.Text, nullable=False)
    create_time = db.Column(db.DateTime, default=datetime.now)
    # 两个外键
    question_id = db.Column(db.Integer, db.ForeignKey("question.id"))
    author_id = db.Column(db.Integer, db.ForeignKey("user.id"))

    # 反向引用，怎么使用该question得到所有的answer
    # 从大到小排序
    question = db.relationship("QuestionModel", backref=db.backref("answers", order_by=create_time.desc()))
    # 查看该人发布的所有answer
    author = db.relationship("UserModel", backref="answers")
