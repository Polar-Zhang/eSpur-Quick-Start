# 数据库配置
HOSTNAME = '120.76.119.71'
# HOSTNAME = '172.16.3.184'
PORT = '3306'
DATABASE = 'eSpur_management'
USERNAME = 'espur'
PASSWORD = 'hiespur'
# USERNAME = 'root'
# PASSWORD = 'espur'
DB_URI = 'mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'.format(USERNAME, PASSWORD, HOSTNAME, PORT, DATABASE)
SQLALCHEMY_DATABASE_URI = DB_URI
SQLALCHEMY_TRACK_MODIFICATIONS = True

SECRET_KEY = "sdfsadfskrwerfj1233453345"

# 邮箱配置
MAIL_SERVER = "smtp.qq.com"
MAIL_PORT = 465
MAIL_USE_TLS = False
MAIL_USE_SSL = True
MAIL_DEBUG = True
MAIL_USERNAME = "490112148@qq.com"
MAIL_PASSWORD = "pazaineqzloscbbi"
MAIL_DEFAULT_SENDER = "490112148@qq.com"
