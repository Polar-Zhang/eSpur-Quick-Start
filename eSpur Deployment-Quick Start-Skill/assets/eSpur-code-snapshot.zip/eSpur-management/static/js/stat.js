function render_graph() {
    // // 通过js发送网络请求： ajax 异步JS和XML
    // $.ajax({
    //     url: "/user/captcha",
    //     method: "POST",
    //     data: {
    //         "email": email
    //     },
    //     success: function (res) {
    //         let code = res['code']
    //         if (code === 200) {
    //             // 取消按钮的点击事件
    //             $this.off("click")
    //             let countDown = 60
    //             let timer = setInterval(function () {
    //                 countDown--
    //                 $this.text("请等待" + countDown + "秒")
    //                 if (countDown === 0) {
    //                     clearInterval(timer)
    //                     $this.text("获取验证码")
    //                     // 重新绑定点击事件
    //                     bindCaptchaBtnClick()
    //                 }
    //             }, 1000)
    //             // alert("发送成功")
    //         } else {
    //             alert(res['message'])
    //         }
    //     }
    // })


    let stat_boxs = document.querySelectorAll("#stat-box")
    for (let i = 0; i < stat_boxs.length; i++) {
        let instance_id = (stat_boxs[i].dataset.id)

        function update_stat() {
            $.ajax({
                url: "/stat/stat",
                method: "POST",
                data: {
                    "instance_id": instance_id
                },
                success: function (res) {
                    let code = res['code']
                    if (code === 200) {
                        update_content(stat_boxs[i], res['save_ratio'] / 100, res['energy_consumed'] / 100, res['energy_saved'] / 100)
                    } else {
                        alert(res['message'])
                    }
                }
            })
        }

        update_stat()
        setInterval(update_stat, 30000) //30秒更新一次统计信息

        function update_graph() {
            $.ajax({
                url: "/stat/realtime_power",
                method: "POST",
                data: {
                    "instance_id": instance_id
                },
                success: function (res) {
                    let code = res['code']
                    if (code === 200) {
                        render_power_chart(stat_boxs[i], res['xLabel'], res['yData'], res['yData1'])
                        update_ratio_state(stat_boxs[i], res['ratio'], res['state'])
                    } else {
                        alert(res['message'])
                    }
                }
            })
        }

        update_graph()
        setInterval(update_graph, 10000) //10秒更新一次power数据
    }
}

//更新统计数据
function update_content(stat_box, save_ratio, energy_consumed, energy_saved) {
    let contents = stat_box.querySelectorAll(".content label")
    // 保留两位小数，但是转换成string类型
    contents[0].innerHTML = (save_ratio).toFixed(2)
    contents[1].innerHTML = energy_consumed
    contents[2].innerHTML = energy_saved
}

function update_ratio_state(stat_box, ratio, state) {
    let contents = stat_box.querySelectorAll(".content label")
    // 保留两位小数，但是转换成string类型
    contents[3].innerHTML = (ratio / 100).toFixed(2)
    render_state_chart(stat_box, state)
}

function render_power_chart(stat_box, xLabel, yData, yData1) {
    let myChart = echarts.init(stat_box.querySelector(".power-graph"));
    option = {
        xAxis: {
            type: 'category',
            data: xLabel
        },
        yAxis: {
            type: 'value'
        },
        series: [{
            data: yData,
            type: 'line'
        }
            // ,
            //     {
            //         data: yData1,
            //         type: 'line',
            //         stack: 'x',
            //         areaStyle: {}
            //     }
        ]
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);
}

function render_state_chart(stat_box, state) {
    let myChart = echarts.init(stat_box.querySelector(".state-graph"));

    let states_color = []
    let data = []
    for (let i = 0; i < state.length; i++) {
        if (state.charAt(i) === '1') {
            states_color.push('#28c984')
        } else {
            states_color.push('#dbf6eb')
        }
        data.push({
            value: 1, //对应显示的部分数据即80%
            itemStyle: {
                normal: {
                    color: states_color[i],
                }
            }
        })
    }


    let option = {
        tooltip: {
            show: false,
            trigger: 'item',
            formatter: "{a} : {c} ({d}%)"
        },
        series: [{
            type: 'pie',
            radius: ['50%', '90%'], //设置内外环半径,两者差值越大，环越粗
            hoverAnimation: false, //移入图形是否放大
            label: { //对应效果图中的Angular显示与否以及设置样式
                // show: true,
                // position: 'center',
                normal: {
                    show: true,
                    position: 'center',
                    padding: [0, 0, 20, 0], //设置字angular的边距
                    fontSize: 16,
                }
            },
            labelLine: {
                normal: { //label线不显示
                    show: false
                }
            },
            data: data
        }]
    };


    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);
}


// 等网页文档所有元素加载完成后执行
$(function () {
    render_graph();
});