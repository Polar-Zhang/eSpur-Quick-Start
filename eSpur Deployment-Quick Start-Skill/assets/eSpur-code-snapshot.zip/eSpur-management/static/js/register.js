function bindCaptchaBtnClick() {
    $("#captcha-btn").on('click', function (event) {
        // this外面套一层$表示 $("#captcha-btn")
        let $this = $(this)
        let email = $("input[name='email']").val()
        // let email = document.querySelector("input[name='email']").value
        // console.log(email)
        if (!email) {
            alert("邮箱为空")
            return
        }
        // 通过js发送网络请求： ajax 异步JS和XML
        $.ajax({
            url: "/user/captcha",
            method: "POST",
            data: {
                "email": email
            },
            success: function (res) {
                let code = res['code']
                if (code === 200) {
                    // 取消按钮的点击事件
                    $this.off("click")
                    let countDown = 60
                    let timer = setInterval(function () {
                        countDown--
                        $this.text("请等待" + countDown + "秒")
                        if (countDown === 0) {
                            clearInterval(timer)
                            $this.text("获取验证码")
                            // 重新绑定点击事件
                            bindCaptchaBtnClick()
                        }
                    }, 1000)
                    // alert("发送成功")
                } else {
                    alert(res['message'])
                }
            }
        })

    });
}

// 等网页文档所有元素加载完成后执行
$(function () {
    bindCaptchaBtnClick();
});