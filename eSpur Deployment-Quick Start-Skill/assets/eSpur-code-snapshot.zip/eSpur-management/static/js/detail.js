function render_graph() {
    let stateGraph = document.querySelector(".state-graph")
    let powerGraph = document.querySelector(".power-graph")
    let startTime = document.querySelector(".head .start-time")
    let endTime = document.querySelector(".head .end-time")
    let instance_id = stateGraph.dataset.id
    // console.log(instance_id)
    $.ajax({
        url: "/stat/detail/graph",
        method: "POST",
        data: {
            "instance_id": instance_id,
            "start_time": startTime.value,
            "end_time": endTime.value
        },
        success: function (res) {
            let code = res['code']
            if (code === 200) {
                render_state_chart(stateGraph, res['xLabel'], res['stateData'])
                render_power_chart(powerGraph, res['xLabel'], res['yData'], res['yData1'])
            } else {
                alert(res['message'])
            }
        }
    })

}

function render_state_chart(stat_box, xLabel, yData) {
    let myChart = echarts.init(stat_box);
    option = {
        xAxis: {
            type: 'category',
            data: xLabel
        },
        yAxis: {
            type: 'value'
        },
        series: [{
            data: yData,
            type: 'line',
        }
            // ,
            //     {
            //         data: yData1,
            //         type: 'line',
            //         stack: 'x',
            //         areaStyle: {}
            //     }
        ]
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);
}

function render_power_chart(stat_box, xLabel, yData, yData1) {
    let myChart = echarts.init(stat_box);
    option = {
        xAxis: {
            type: 'category',
            data: xLabel
        },
        yAxis: {
            type: 'value'
        },
        series: [{
            data: yData,
            type: 'line'
        }
            // ,
            // {
            //     data: yData1,
            //     type: 'line',
            //     stack: 'x',
            //     areaStyle: {}
            // }
        ]
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);
}

function set_start_and_end_time() {
    let startTime = document.querySelector(".head .start-time")
    let endTime = document.querySelector(".head .end-time")
    //2020-02-06T15:20
    let today = new Date();//返回当前日期时间
    let half_day_ago = new Date(today.getTime() - 12 * 3600 * 1000)
    let end_time = getFormattedTime(today)
    let start_time = getFormattedTime(half_day_ago)

    endTime.value = end_time
    startTime.value = start_time

    function getFormattedTime(time) {
        let yyyy = time.getFullYear()
        let MM = time.getMonth() + 1;//因为getMonth()方法获取的是索引值,所以要＋1
        let dd = time.getDate();//返回一个月中的某一天
        let hh = time.getHours();//返回小时 (0 ~ 23)
        let mm = time.getMinutes();//返回分钟 (0 ~ 59)
        MM = checkTime(MM);//调用下面的checkTime函数，设置小于10的时间数字格式，例如5秒显示成05秒
        dd = checkTime(dd);
        hh = checkTime(hh);
        mm = checkTime(mm);
        return yyyy + "-" + MM + "-" + dd + "T" + hh + ":" + mm;
    }

    function checkTime(i) {
        if (i < 10) {
            i = "0" + i;//这里如果是一位数则在前面添加一位0
        }
        return i;
    }

}

function set_search_btn_event() {
    let searchBtn = document.querySelector(".head .time-selectors button")
    searchBtn.addEventListener("click", function () {
        render_graph()
    })
}

// 等网页文档所有元素加载完成后执行
$(function () {
    set_start_and_end_time()
    set_search_btn_event()
    render_graph();
});